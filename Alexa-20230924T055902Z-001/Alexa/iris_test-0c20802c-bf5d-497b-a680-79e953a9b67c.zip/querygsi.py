import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
client = boto3.client('dynamodb')
table = dynamodb.Table('alexa_demo_table3')

def lambda_handler(event, context):
    # r_response = table.query(
    #     IndexName='email-time2-index',
    #     KeyConditionExpression=Key('email').eq(event["body"]["email"]),
    #     ProjectionExpression="#e, #d, #t",
    #     ExpressionAttributeNames={"#e":"email", "#d":"date", "#t":"time2"},
    #     ScanIndexForward= True
    # )
    # 
    
    # queryString = 
    # queryNames = 
    # queryValues =           "ExpressionAttributeNames" : queryNames,
    TABLE_NAME = 'alexa_demo_table3'
    kwargs = {"TableName": TABLE_NAME, 
              "IndexName":'email-time2-index',
              "KeyConditionExpression" : '#email = :email',
              # "ExpressionAttributeNames" : {
              #   "#email" : "email"
              # },
              "ExpressionAttributeValues" : {
                ':email': {'S': 'iris.nguyen@atcs.com'}
              },
              "Select": 'COUNT',
              "ScanIndexForward":True
            }
            
    c_response = client.query(**kwargs)
    
    return c_response