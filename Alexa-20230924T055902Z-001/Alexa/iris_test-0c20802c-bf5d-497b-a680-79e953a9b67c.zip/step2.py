import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event,context):
     dynamodb = boto3.resource('dynamodb')
     table = dynamodb.Table('prat-ctap-promomats-clean-dev')
     table1 = dynamodb.Table('prat-ctap-user-assignments-table')
     resp = table.scan(AttributesToGet=['unique_id'])
     resp1= table1.scan(AttributesToGet=['unique_id'])
     c = resp['Items']
     a = resp1['Items']
     for i,j in zip(c,a):
          try:
               if i['unique_id'] == j['unique_id']:
                    match=[]
                    match.append(i)
               else:
                    nomatch=[]
                    nomatch = [i for i in c if i not in a]
                    for i in nomatch:
                         h=i['unique_id']
                         response= table.scan(FilterExpression=Attr('unique_id').eq(h))
                         list1=['market','unique_id','global_version_id','id']
                         list2=[]
                         for i in response['Items']:
                              list2.append((i['country'],i['unique_id'],i['global_version_id'],i['id']))
                              out = []
                              out = [item for t in list2 for item in t]
                              aa = {k:v for k,v in zip(list1,out)}
                              mr =[]
                              for i in aa['market']:
                                   mr.append(i)
                              for i in mr:
                                   list3=[]
                                   list3.extend((i,aa['unique_id'],aa['global_version_id'],aa['id']))
                                   bb = {k:v for k,v in zip(list1,list3)}
                                   response1=table1.put_item(Item=bb)
          except:
               print('ERROR')