import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr
dynamodb = boto3.resource('dynamodb')

CLEAN_TABLE = dynamodb.Table('prat-ctap-promomats-clean-dev')
ASSIGNMENT_TABLE = dynamodb.Table('prat-ctap-user-assignments-table')
USER_FEEDBACK_TABLE = dynamodb.Table('prat-ctap-userFeedback-table')
TAGS_TABLE = dynamodb.Table('prat-ctap-feedbackapp-tags')
PREDICTION_TABLE = dynamodb.Table('prat-ctap-webapp-prediction-table')

CLEAN_RESPONSE_ID=CLEAN_TABLE.scan(AttributesToGet=['unique_id'])
ASSIGNMENT_RESPONSE_ID=ASSIGNMENT_TABLE.scan(AttributesToGet=['unique_id'])
USER_FEEDBACK_RESPONSE_ID=USER_FEEDBACK_TABLE.scan(AttributesToGet=['unique_id'])


TAGS_RESPONSE=TAGS_TABLE.scan()
ASSIGNMENT_RESPONSE=ASSIGNMENT_TABLE.scan()
USER_FEEDBACK_RESPONSE=USER_FEEDBACK_TABLE.scan()
PREDICTION_TABLE_RESPONSE = PREDICTION_TABLE.scan()


def lambda_handler(event,context):
    clean_to_asg()
    clean_to_feed()
    tags_to_asg()
    tags_to_feed()
    pred_to_asg()
    pred_to_feed()
    return 
    
     #CLEAN_2_ASSIGNMENT

def clean_to_asg():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-promomats-clean-dev')
    #  table1 = dynamodb.Table('prat-ctap-user-assignments-table')
    #  resp = table.scan(AttributesToGet=['unique_id'])
    #  resp1= table1.scan(AttributesToGet=['unique_id'])
     c = CLEAN_RESPONSE_ID['Items']
     a = ASSIGNMENT_RESPONSE_ID['Items']
     for i,j in zip(c,a):
          try:
               if i['unique_id'] == j['unique_id']:
                    match=[]
                    match.append(i)
               else:
                    nomatch=[]
                    nomatch = [i for i in c if i not in a]
                    for i in nomatch:
                         h=i['unique_id']
                         response= table.scan(FilterExpression=Attr('unique_id').eq(h))
                         list1=['market','unique_id','global_version_id','id','document_creation_date','document_number','filename','status','type','product','resource_type1','version_modified_date']
                         list2=[]
                         for i in response['Items']:
                              list2.append((i['country'],i['unique_id'],i['global_version_id'],i['id'],i['document_creation_date'],i['document_number'],i['filename'],i['status'],i['type'],i['product'],i['resource_type1'],i['version_modified_date']))
                              out = []
                              out = [item for t in list2 for item in t]
                              aa = {k:v for k,v in zip(list1,out)}
                              mr =[]
                              for i in aa['market']:
                                   mr.append(i)
                              for i in mr:
                                   list3=[]
                                   list3.extend((i,aa['unique_id'],aa['global_version_id'],aa['id'],aa['document_creation_date'],aa['document_number'],aa['filename'],aa['status'],aa['type'],aa['product'],aa['resource_type1'],aa['version_modified_date']))
                                   bb = {k:v for k,v in zip(list1,list3)}
                                   response1=table1.put_item(Item=bb)
          except:
               print('ERROR')
 
     #CLEAN_TO_FEEDBACK 
     
def clean_to_feed():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-promomats-clean-dev')
    #  table1 = dynamodb.Table('prat-ctap-userFeedback-table')
    #  resp = table.scan(AttributesToGet=['unique_id'])
    #  resp1= table1.scan(AttributesToGet=['unique_id'])
     c = CLEAN_RESPONSE_ID['Items']
     f = USER_FEEDBACK_RESPONSE_ID['Items']
     for i,j in zip(c,f):
          try:
               if i['unique_id'] == j['unique_id']:
                    match=[]
                    match.append(i)
               else:
                    nomatch=[]
                    nomatch = [i for i in c if i not in f]
                    for i in nomatch:
                         h=i['unique_id']
                         response= table.scan(FilterExpression=Attr('unique_id').eq(h))
                         list1=['market','unique_id','global_version_id','id','document_creation_date','document_number','filename','status','type','product','resource_type1','version_modified_date']
                         list2=[]
                         for i in response['Items']:
                              list2.append((i['country'],i['unique_id'],i['global_version_id'],i['id'],i['document_creation_date'],i['document_number'],i['filename'],i['status'],i['type'],i['product'],i['resource_type1'],i['version_modified_date']))
                              out = []
                              out = [item for t in list2 for item in t]
                              aa = {k:v for k,v in zip(list1,out)}
                              mr =[]
                              for i in aa['market']:
                                   mr.append(i)
                              for i in mr:
                                   list3=[]
                                   list3.extend((i,aa['unique_id'],aa['global_version_id'],aa['id'],aa['document_creation_date'],aa['document_number'],aa['filename'],aa['status'],aa['type'],aa['product'],aa['resource_type1'],aa['version_modified_date']))
                                   bb = {k:v for k,v in zip(list1,list3)}
                                   response1=table1.put_item(Item=bb)
          except:
               print('ERROR')
               
     #Tags_to_Assignment
     
def tags_to_asg():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-feedbackapp-tags')
    #  table1= dynamodb.Table('prat-ctap-user-assignments-table')
    #  resp = table.scan()
    #  resp1 = table1.scan()
     tag = TAGS_RESPONSE['Items']
     asg = ASSIGNMENT_RESPONSE['Items']
     for i in tag:
        for j in asg:
            Dict = dict({'market': j['market'], 'unique_id': j['unique_id']})
            if j.get(i['field_name']):
                list1=[]
                for p in i['field_values']:
                    
                    list1.append(p)
                    list3 = {'Possible_values':list1,'Has_Predictions':False}
                    table1.update_item(
                        Key=Dict,
                    UpdateExpression= "SET "+i['field_name']+" =:u", 
                    ExpressionAttributeValues={
                        ":u": list3,
                    }
                    )
                
            else:
                pop = []
                for p in i['field_values']:
                    pop.append(p)
                    list2 = {'Possible_values':pop,'Has_Predictions':False}
                    table1.update_item(
                        Key= Dict,
                    UpdateExpression= "SET "+i['field_name']+" =:u",
                    ExpressionAttributeValues={
                        ":u": list2,
                    
                    }
                    ) 
                    
     #Tags_to_Feedback
     
def tags_to_feed():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-feedbackapp-tags')
    #  table1= dynamodb.Table('prat-ctap-userFeedback-table')
    #  resp = table.scan()
    #  resp1 = table1.scan()
     tag = TAGS_RESPONSE['Items']
     fdk = USER_FEEDBACK_RESPONSE['Items']
     
     for i in tag:
        for j in fdk:
            Dict = dict({'market': j['market'], 'unique_id': j['unique_id']})
            ab1 = dict({i['field_name'] :{'default'}})
            table1.update_item(
                Key=Dict,
            UpdateExpression= "SET tags =:u",
            ExpressionAttributeValues={
                ":u": ab1
                    
            }
            )
     
     table2 = dynamodb.Table('prat-ctap-feedbackapp-tags')
     table3= dynamodb.Table('prat-ctap-userFeedback-table')
     
     resp2 = table2.scan()
     resp3 = table3.scan()
     tag2 = resp2['Items']
     fdk3 = resp3['Items']        
     
     for i in tag2:
        for j in fdk3:
            Dict1 = dict({'market': j['market'], 'unique_id': j['unique_id']})
            ab2 = dict({'prediction_occurrence' :{'prediction':'Default'}})
            table3.update_item(
                Key=Dict1,
            UpdateExpression= "SET tags."+i['field_name']+" =:u",
            ExpressionAttributeValues={
                ":u": ab2
                    
            }
            )
            
     #Prediction_to_Assignment
     
def pred_to_asg():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-webapp-prediction-table')
    #  table1= dynamodb.Table('prat-ctap-user-assignments-table')
    #  resp = table.scan()
    #  resp1 = table1.scan()
    
     prd = PREDICTION_TABLE_RESPONSE['Items']
     asg = ASSIGNMENT_RESPONSE['Items']
     for i in asg:
        Dict = dict({'market': i['market'], 'unique_id': i['unique_id']})
        for j in prd:
            list2=[p for p in j if p!='unique_id']
           
            if i['unique_id'] == j['unique_id']:
                   
                for t in list2:
     
                    list3= {'Has_Predictions':True, 'Prediction':j[t]['Prediction'],'Last_user_response':j[t]['Last_user_response']}
                    table1.update_item(
                    Key=Dict,
                    UpdateExpression= "SET "+t+" =:u",
                    ExpressionAttributeValues={
                        ":u": list3
                    }
                    )
                    
     #Prediction_to_feedback
     
def pred_to_feed():
    #  dynamodb = boto3.resource('dynamodb')
    #  table = dynamodb.Table('prat-ctap-webapp-prediction-table')
    #  table1= dynamodb.Table('prat-ctap-userFeedback-table')
    #  resp = table.scan()
    #  resp1 = table1.scan()
     prd = PREDICTION_TABLE_RESPONSE['Items']
     fdb = USER_FEEDBACK_RESPONSE['Items']
     
     
     for i in fdb:
        Dict = dict({'market': i['market'], 'unique_id': i['unique_id']})
        for j in prd:
            list2=[p for p in j if p!='unique_id']
           
            if i['unique_id'] == j['unique_id']:
                   
                for t in list2:
                    table1.update_item(
                    Key=Dict,
                    UpdateExpression= "SET tags."+t+".prediction_occurrence.prediction =:u",
                    ExpressionAttributeValues={
                        ":u": j[t]['Prediction']
                    }
                    )

