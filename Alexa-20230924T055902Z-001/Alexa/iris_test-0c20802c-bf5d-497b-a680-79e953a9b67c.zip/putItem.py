"""
Your module description
"""
import boto3
import json

#dynamodb = boto3.resource('dynamodb')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('flowers')

def lambda_handler(event, context):
    #If id already exists, will modify old into new value
    table.put_item(Item={'id':'lily', 'price': '20'})
    # print(response) #never use print in lambda
    response = {'message' : 'Item added'}
    return {
        'statusCode' : 200,
        'body': response
    }