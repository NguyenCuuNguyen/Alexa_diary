import boto3
import json
import time
import urllib

# Get the service resource
s3 = boto3.client('s3')
s3_client = boto3.resource(u's3')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
    copy_source = {'Bucket':source_bucket , 'Key':key}
    print(event)
    
    json_object = s3_client.get_object(Bucket=source_bucket,Key=key)
    jsonFileReader = json_object['Body'].read()
    jsonDict = json.loads(jsonFileReader)
    table = dynamodb.Table('alexa_demo_table2')
    table.put_item(Item=jsonDict)
    
    