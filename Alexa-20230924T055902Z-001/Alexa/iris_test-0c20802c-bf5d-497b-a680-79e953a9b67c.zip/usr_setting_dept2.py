import boto3
import json
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ctap-user-table-tester')
#TODO: env vars
#TODO: error proof for error event => check if key is in event["key"], send back message
product = "Keytruda"

#Step 0: create deparment: TODO: change hard code
def create_department(table, numRows, event):
    depts=[]
    for i in range(numRows):
        depts.append(product)
    return depts

#Step 1: Create User settings => #Update user table with new settings
def create_settings(table, event):
    match=table.scan( #scan to get all rows of multiple columns
        AttributesToGet=["isid", "market", "department"] #TODO: Replace with status, resource_type, product, my_profile (department)
    )
    # Send numRows to create numDepts:
    numRows = table.item_count
    depts = create_department(table, numRows, event)
   
    for group in match["Items"]:
        for i in range(numRows): #cannot use and in above for loop
            #group.append(depts)
            
            table.update_item(
                Key={
                    "isid": group["isid"],
                    "market" : group["market"]
                },
                UpdateExpression= "SET department = :p, user_settings = :m", #shows attributes to modify and values to assign to it #TODO: Learn syntax for UpdateExpression
                ExpressionAttributeValues={
                    ":p": depts[i],
                    ":m": group
                }
            )
            

#Step 2: Query user table for existing settings TODO: remove hard-code.
def query_settings(table, event):
    event = event["body"]
    response = table.get_item(Key={'isid': event['isid'], 'market': event['market']}, AttributesToGet=['user_settings'])
    return response

#Step 3: return query through api gateway
def lambda_handler(event, context):
    create_settings(table, event)
    response = query_settings(table, event) 
    print(response) 
   
    