import json
import boto3


def lambda_handler(event, context):

    client = boto3.client('textract')
    response = client.analyze_document( \
        Document={'S3Object': {'Bucket': "iris-textract-test", 'Name': "sample-image.png"}}, FeatureTypes= ['TABLES','FORMS'])
        
    print(response)
    
    return {
        'statusCode': 200,
        'body': response#json.dumps("Success")
    }