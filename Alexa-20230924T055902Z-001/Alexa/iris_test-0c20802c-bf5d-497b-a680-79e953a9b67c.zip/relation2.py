import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr
def lambda_handler(event,context):
     dynamodb = boto3.resource('dynamodb')
     table_a = dynamodb.Table('assignment-table-sandbox')
     #table_r = dynamodb.Table('prat-ctap-relationship-dev')
     table_c = dynamodb.Table('components-clean-sandbox')
     asID = table_a.scan(AttributesToGet=['unique_id'])
     print(asID['Items']) #[{'unique_id': '455_12930_81-JP_HCP.pdf'}, {'unique_id': '23755_10890-Bel_button.pdf'},...]
     print("\n")
     	
     cleanID = table_c.scan(AttributesToGet=["unique_id"])
     print(cleanID['Items'])
     print("\n")
     
     for i in asID['Items']:
          for key in i.values():
               #print(key) #455_12930_81-JP_HCP.pdf \n ....
               # print("\n")
               print(i.values())
               # for j in cleanID['Items']:
               #      for key2 in j.values():
               #           print(key2)
     
     #assignID'sValue -> cleanTableID'sValue
     # for assign, clean in zip(asID['Items'], cleanID['Items']):
     #      print(f'{asID['Items']} -> {cleanID['Items']}')
               
               