import boto3
import os
from botocore.exceptions import ClientError

TABLE_NAME = "alexa_demo_table2"

def create_feedback_tb(dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb') #endpoint_url
        table_names = [table.name for table in dynamodb.tables.all()]
        if TABLE_NAME in table_names:
            print("Table " + TABLE_NAME + " already exists.")
        else:
            table = dynamodb.Table(TABLE_NAME)
            
            print("Table " + TABLE_NAME + " does not exist. Create the table:")
            
            table = dynamodb.create_table(
                TableName = TABLE_NAME,
                KeySchema=[
                    {
                        'AttributeName': 'email', #WR Number
                        'KeyType': 'HASH' #Partition Key
                    }, 
                    {
                        'AttributeName': 'Date', #don't see equivalent in WR
                        'KeyType': 'RANGE' #Sort Key 
                    }
                ],
                AttributeDefinitions=[
                    {
                        'AttributeName': 'email', #WR Number
                        'AttributeType': 'S'
                    }, 
                    {
                        'AttributeName': 'Date', #don't see equivalent in WR
                        'AttributeType': 'S' 
                    }
                ],
                ProvisionedThroughput={
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            )
        # elif ce.response['Error']['Code'] == "ResourceInUseException":
        #     pass
        
    #return table

def lambda_handler(event, context):
  #  table = create_feedback_tb()
    create_feedback_tb()
    #print("Table status:", table.table_status)