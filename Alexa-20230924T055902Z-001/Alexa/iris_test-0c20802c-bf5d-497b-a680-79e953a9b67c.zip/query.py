"""
Your module description
"""
import json
from boto3.dynamodb.types import TypeDeserializer
from boto3.dynamodb.conditions import Key, Attr
import boto3
dynamodb = boto3.client('dynamodb')
deserializer = TypeDeserializer()
def scan_table(dynamo_client, TableName, event):
    paginator = dynamo_client.get_paginator("scan")
    filExp = {}
    queryString = ""
    for key in event:
        queryString += key + " = :" + key + " and "
        if (type(event[key])==str):
            filExp[":" + key] = {"S": event[key]}
        else:
            filExp[":" + key] = {"BOOL": event[key]}
    queryString = queryString.rsplit(" and ", 1)[0]
    print(queryString, filExp)
    for page in paginator.paginate(TableName=TableName, 
            FilterExpression=queryString,
            ExpressionAttributeValues=filExp):
        yield from page["Items"]
def get_summary_table(dynamodb, event):
    items = []
    for item in scan_table(dynamodb, "Assignment_Table1", event):
        python_data = {k: deserializer.deserialize(v) for k,v in item.items()}
        items.append(python_data)
    #df = pd.DataFrame(items)
    return(items)
def lambda_handler(event,context):
    print(event)
    df = get_summary_table(dynamodb, event)
    print(df)
    # df1= df[{'unique_id','Assignment_Title'}]
    # df2= df[{'content_purpose'}]
    # data1=df1.to_dict(orient='records')
    # print(df)
    # ### list 
    # data2=df2.to_dict(orient='list')
    # print(data2)
    # ### dictionary
    # data3=data2.copy()
    # data1.append(data3)
    # print(data1)
    python_data={'Assignments': df}
    return python_data
    
    
    import json
from boto3.dynamodb.types import TypeDeserializer
from boto3.dynamodb.conditions import Key, Attr
import boto3
dynamodb = boto3.client('dynamodb')
deserializer = TypeDeserializer()
def scan_table(dynamo_client, TableName, event):
    paginator = dynamo_client.get_paginator("scan")
    filExp = {}
    queryString = ""
    for key in event:
        queryString += key + " = :" + key + " and "
        if (type(event[key])==str):
            filExp[":" + key] = {"S": event[key]}
        else:
            filExp[":" + key] = {"BOOL": event[key]}
    queryString = queryString.rsplit(" and ", 1)[0]
    print(queryString, filExp)
    for page in paginator.paginate(TableName=TableName, 
            FilterExpression=queryString,
            ExpressionAttributeValues=filExp):
        yield from page["Items"]
def get_summary_table(dynamodb, event):
    items = []
    for item in scan_table(dynamodb, "Assignment_Table1", event):
        python_data = {k: deserializer.deserialize(v) for k,v in item.items()}
        items.append(python_data)
    #df = pd.DataFrame(items)
    return(items)
def lambda_handler(event,context):
    print(event)
    df = get_summary_table(dynamodb, event)
    print(df)
    # df1= df[{'unique_id','Assignment_Title'}]
    # df2= df[{'content_purpose'}]
    # data1=df1.to_dict(orient='records')
    # print(df)
    # ### list 
    # data2=df2.to_dict(orient='list')
    # print(data2)
    # ### dictionary
    # data3=data2.copy()
    # data1.append(data3)
    # print(data1)
    python_data={'Assignments': df}
    return python_data
    
    
    