import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event,context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('prat-ctap-webapp-prediction-table')
    table1 = dynamodb.Table('prat-ctap-userFeedback-table')
    # resp1 = table1.query(KeyConditionExpression=Key('market').eq('United States')&Key('unique_id').eq('23755_10890-Bel_button.pdf'))
    resp=table.scan()
    resp1 = table1.scan()
    pred = resp['Items']
    feed = resp1['Items']
    
    L=[]
    for i in pred:
        for j in feed:
            for (k,v) in i.items():
                Dict = dict({'market': j['market'], 'unique_id': j['unique_id']})
                if k=='content_pillar':
                    L.append(v)
                    for m in L:
                        aa= m['Prediction']
                        # print(aa)
                        for pp in j['tags']:
                            print(pp)
                            table1.update_item(
                                Key=Dict,
                            UpdateExpression= "SET tags."+pp+".prediction_occurrence.prediction =:u",
                            ExpressionAttributeValues={
                                ":u": aa
                            }
                            )
                # else:
                #     print('shivam')