# -*- coding: utf-8 -*-
"""
Created on Fri Dec 11 09:44:30 2020

@author: wilkincr
"""

import boto3
import botocore
import os
#list_s3_objects retursn all objects/files in 'zinc dev bucket' and 'desktop link' buckets. Item_list stores all the object names. 

def list_s3_objects(s3, data_prefix, bucket_name):
    item_list = []
#    print("listing s3 objects")
    kwargs = {"Bucket": bucket_name, "Prefix": data_prefix}
    continuationToken = True
    while continuationToken:
        objects = s3.list_objects_v2(**kwargs) #listobjectsv2 Returns some or all (up to 1,000) of the objects in a bucket with each request.
        try:
            for obj in objects["Contents"]: #Itereate thru the old list of S3 objects, append each to item_list
                item_list.append(obj["Key"]) 
            if "NextContinuationToken" in objects: #NextContinuationToken is sent <= isTruncated is true = more keys in the bucket that can be listed
                kwargs["ContinuationToken"] = objects["NextContinuationToken"] #In the following subsequent request,  include a continuation-token query parameter in the request with preceding response's NextContinuationToken 
            else:
                continuationToken = False
        except KeyError:
            continuationToken = False
    print("total files in " + bucket_name + ":", len(item_list)) #item_list = total files in a bucket
    return item_list

# Create Clients
s3_dev = boto3.client('s3',
aws_access_key_id='',
aws_secret_access_key='',
aws_session_token=''  )

s3_prod = boto3.client('s3',
aws_access_key_id='',
aws_secret_access_key='',
aws_session_token='')

prod_bucket_name = 'zinc dev bucket'
bucket_name = 'desktop link'
kmsKey = ''
# List all objects in each
for id1 in item_list:
    
    dev_list = list_s3_objects(s3_dev, str(id1)+"/", bucket_name)
    prod_list = list_s3_objects(s3_prod, str(id1)+"/", prod_bucket_name)

#Not downloading the files but iterating thru dev_list and prod_list, find keys that are in dev_list but not in prod_list, download them and upload to production bucket 
count = 0
for val in dev_list:
    if val not in prod_list:
        print(count)
        tmpFile= val.split("/")[-1]
        tmpFile = "val." + val.split(".")[-1]
        s3_dev.download_file(bucket_name, val, os.getcwd() + '\\' + tmpFile) #getcwd() returns current working directory of a process.
        s3_prod.upload_file(tmpFile, prod_bucket_name, val,  {'SSEKMSKeyId': kmsKey, 'ServerSideEncryption': 'aws:kms'})
        os.remove(os.getcwd() + '\\' + tmpFile)
        count += 1

        
print(set(dev_list)-set(prod_list))
print(set(prod_list)-set(dev_list))
