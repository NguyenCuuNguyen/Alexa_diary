import boto3
import json
import logging #use logger to traceback error, include aws_request_id for Insight query
import sys

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('flowers')

def lambda_handler(event, context):
    try:
        logger.info(f'event: {event}')
        response = table.get_item(Key={'id':'iris'})
        # print(response) #never use print in lambda
        logger.info(f'The response is: {id}')
        return {
            'statusCode' : 200,
            'body': response
        }
    except Exception as exp:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)