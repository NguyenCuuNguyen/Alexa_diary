import json
import boto3
import base64

def lambda_handler(event, context):
    eventBody = json.loads(json.dumps(event))['body']
    base64Img = json.loads(eventBody)['Image']
    
    textract = boto3.client('textract') #Textract client
    response = textract.detect_document_#Call textract
    