iimport boto3
import json
from boto3.dynamodb.conditions import Key, Attr
from boto3.dynamodb.types import TypeDeserializer
dynamodb = boto3.resource('dynamodb')
user_table= dynamodb.Table("user_Table")
dynamoclient=boto3.client('dynamodb')
deserializer = TypeDeserializer()

dynamopaginator = dynamoclient.get_paginator('scan')
list_isid=[]
for page in dynamopaginator.paginate(TableName="user_Table"):
        for item in page['Items']:
            deserialized_fields = {k: deserializer.deserialize(v) for k, v in item.items()}
            list_isid.append(deserialized_fields['isid'])

def query_prev_settings(header):
    user_settings_status = user_table.query( #current user settings before update
            KeyConditionExpression=Key("isid").eq(header["isid"]),
            ProjectionExpression="user_settings"
    )
    return user_settings_status
    
def update_new_settings(updated_settings, header):
    user_table.update_item(
                    Key={
                        "isid": header["isid"]
                    },
                    UpdateExpression= "SET #b = :m",
                    ExpressionAttributeValues={
                        ":m": updated_settings
                    },
                    ExpressionAttributeNames={
                        '#b': "user_settings"
                    },
                    ReturnValues="UPDATED_NEW"
                )

def query_settings(event, context):
    #get isid from User's GET request from API level.
    global header
    header = event["headers"]
    if event["headers"]["isid"] != "":
        user_settings_status = query_prev_settings(header)
        if event["headers"]["isid"] in list_isid:
            if event["method"] =="POST":
                if user_settings_status['Items'][0]==event['body']:
                    return "NO update to User settings"
                else: 
                    if "user_settings" in event['body'] and "isid" in event["headers"]: #POST Request
                        #Update setting for non-existing setting:
                        if user_settings_status["Items"] == [{}]:
                            update_new_settings(event['body']['user_settings'], event["headers"])
                            return "Success"
                        try:
                            [prev_settings] = user_settings_status["Items"] #get rid of extra outer list []
                            new_settings = event["body"]["user_settings"]
                            prev_key_list = []  #contains previous list's keys
                            for setting, updated_settings in prev_settings.items():
                                for key in updated_settings:
                                    prev_key_list.append(key)
                                    if key in new_settings:
                                        updated_settings[key] = new_settings[key]
                            non_exist_settings={}
                            #Create dynamically new rows:
                            for setting in new_settings:
                                if setting not in prev_key_list:
                                    updated_settings[setting] = new_settings[setting]
                            update_new_settings(updated_settings, event["headers"])
                            response = "Success!"
                        except: 
                            print("Error! No update to User_settings")
                    else:
                            response = "User setting is required for POST requests"
            elif event["method"] == "GET":
                response = query_prev_settings(event["headers"])
                if response["Items"] == [{}]: 
                     return "User settings does not yet exist for this ISID" 
                return response["Items"]
        else:
            response = "The username doesn't exist"
    else:
        response = "Username cannot be empty"
    return response 
        
    
def lambda_handler(event, context):
    response = query_settings(event, context)
    return response