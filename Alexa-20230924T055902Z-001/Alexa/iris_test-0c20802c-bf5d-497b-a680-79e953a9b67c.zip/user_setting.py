#"market"="Japan"&"unique_id"="455_12930_81-JP_HCP.pdf"

import boto3
import json
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('assignment-table-sandbox')

#Step 1: Create User settings => #Update user table with new settings
def create_settings(table, event):
    match=table.scan( #scan to get all rows of multiple columns
        AttributesToGet=["market", "global_version_id", "unique_id"] #replace global_version_id with "department" 
    )
    for group in match["Items"]:
        table.update_item(
            Key={
               "market" : group["market"],
               "unique_id": group["unique_id"]
            },
            UpdateExpression= "SET user_settings = :m", #shows attributes to modify and values to assign to it #TODO: Learn syntax for UpdateExpression
            ExpressionAttributeValues={
                ":m": group
            }
        )

   
#Step 2: Query user table for existing settings TODO: remove hard-code.
def query_settings(table, event):
    event = event["body"]
    #paginator = dynamodb_client.get_paginator("scan")
    response = table.get_item(Key={'market': event['market'], 'unique_id': event['unique_id']}, AttributesToGet=['user_settings'])
    return response

#Step 3: return query through api gateway
def lambda_handler(event, context):
    create_settings(table, event)
    response = query_settings(table, event) 
    return response
    
 # add-action ::=
#     path value
   #fields come from the wireframe, table=user table, 
    