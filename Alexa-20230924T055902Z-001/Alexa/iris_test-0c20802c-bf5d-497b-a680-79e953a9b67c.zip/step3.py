import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr
def lambda_handler(event,ccontext):
    dynamodb = boto3.resource('dynamodb')
    table1= dynamodb.Table('prat-ctap-user-assignments-table')
    #resp = table.scan(FilterExpression=Attr('unique_id').eq('23755_10891-Pet2000-12-2018.pdf'))
    #resp1= table1.scan()
    #asg= (resp1['Items'])
    #print(resp1['Items'])
    aa = {'new':{
    "Access": "fake1",
    "Access and Coverage": "fake2",
    "Coverage": "fake3"
        }}
     
    
    table1.update_item(
            Key={
                'unique_id': '23755_10890-Bel_button.pdf',
                'market' : 'United States' 
            },
            UpdateExpression= "SET content_pillar.Possible_Values =:u",
            ExpressionAttributeValues={
            ":u": aa
        }
    )
    # response = table.get_item(
    #     Key={
    #         'unique_id': '23755_10891-Pet11-12-2018.pdf'
    #     }
          
    # )
    # item = response['Item']
    # print(item)       



