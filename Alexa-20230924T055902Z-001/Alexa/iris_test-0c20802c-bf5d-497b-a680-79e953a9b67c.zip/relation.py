import boto3
import numpy as np
import pandas as pd
from boto3.dynamodb.types import TypeDeserializer
deserializer = TypeDeserializer()
from boto3.dynamodb.conditions import Key, Attr
def lambda_handler(event,context):
     dynamodb = boto3.resource('dynamodb')
     table_a = dynamodb.Table('prat-ctap-user-assignment-table')
     table_r = dynamodb.Table('prat-ctap-relationship-dev')
     table_c = dynamodb.Table('prat-ctap-component-clean-dev')
     resp = table_a.scan(AttributesToGet=['unique_id'])
     resp1= table_r.scan(AttributesToGet=['unique_id'])
     print(resp['Items'])
     print(resp1['Items']) 
     for i in resp['Items']:
          for key in i.values():
               # print(key)
               for j in resp1['Items']:
                    for key1 in j.values():
                         print(key1)
                         if key==key1:
                              print("match")
                         else:
                              for z in resp['Items']:
                                   if not z in resp1['Items']:
                                        print(z)
                                        h=z['unique_id']
                                        print(h)
                              print("no match")
                              response= table_a.scan(
                                   FilterExpression=Attr('unique_id').eq(h)
                              )
                              # return response
                              list1=['unique_id','source_document_id','type']
                              list2=[]
                              for i in response['Items']:
                                   # return i
                                   list2.append((i['unique_id'],i['source_document_id'],i['type']))
                                   # return list2
                              output_a = []
                              output_a = [item for t in list2 for item in t]
                              aa = {k:v for k,v in zip(list1,output_a)}
                              # return aa
                              response1=table_r.put_item(Item=aa)
                              
                              
                              #filter/scan relationship table <table_r> on relationship.items.source_document_id
                              #
     # table_rc = dynamodb.Table('prat-ctap-relationship-dev')
     # unique_id_c = table_rc.scan(AttributesToGet=['unique_id'])
     
     # print(unique_id_c)
     # resp2= table_c.scan(AttributesToGet= ['unique_id'])
     # resp3= unique_id_c                         
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              # z=(key!=key1)
                              # response = table.scan(
                              # #AttributesToGet=['unique_id'],
                              # ScanFilter={
                              # "unique_id": {
                              # "AttributeValueList": [f"{z}"],
                              # "ComparisonOperator": "CONTAINS"
                              # }
                              # })
                              # #print(response.keys())
                              # return response['Items']
                              # n=table.scan(AttributesToGet=['z'])
                              # print(n)
                              # response= table.scan(FilterExpression=Attr('unique_id').eq(key!=key1))
                              # print(response['Items'])
                              # tt=table.scan(AttributesToGet=['unique_id',
                              # 'approval date','document_number','file_subtype',
                              # 'filename','id','market','product','source_document_id','type'])
                              # print(tt)
                              # table1.update_item(
                              #           Key={
                              #                'market': 'United States',
                              #                'unique_id':'23755_10890-Bel_button.pdf'
                              #           },
                              #           UpdateExpression= "SET relationships.Items = :label",
                              #           ExpressionAttributeValues={
                              #           ":label": aa
                              #           }
                              # )
                              # response = table.get_item(
                              #      Key={
                              #           'market': 'United States',
                              #           'unique_id':'23755_10890-Bel_button.pdf'
                              #      }
                              # )
                              # response= table1.put_item(
                              #      TableName='prat-ctap-relationships-dev',
                              #      Item={
                              #           'tt'
                              #      }
                              # )
                              
                              # for i in response['Items']:
                              #      print(i)
                              # df = get_summary_table(dynamodb)
                              # # df = pd.DataFrame(response['Items'])
                              # return(df)
                              
                              # def get_summary_table(dynamodb):
                              #      table = dynamodb.Table('prat-ctap-user-assignment-table')
                              #      response= table.scan(FilterExpression=Attr('unique_id').eq(key))
                              #      for item in response:
                              #           python_data = {k: deserializer.deserialize(v) for k,v in item.items()}
                              #           items.append(python_data)
                              #           df = pd.DataFrame(items)
                              #           return(df)

# def scan_table(dynamo_client, TableName, **kwargs):
#      paginator = dynamo_client.get_paginator("scan")
#      for page in paginator.paginate(TableName=TableName, **kwargs):
#           yield from page["Items"]
# def get_summary_table(dynamodb):
#      table = dynamodb.Table('prat-ctap-user-assignment-table')
#      response= table.scan(FilterExpression=Attr('unique_id').eq('23755_0-Pet11-12-2018.pdf'))
#      for item in response['Items']:
#           print(item)
#           python_data = {k: deserializer.deserialize(v) for k,v in item.response['Items']}
#           items.append(python_data)
#           df = pd.DataFrame(items)
#           return(df)